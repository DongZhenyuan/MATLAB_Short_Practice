matlab -nodisplay -nojvm -r "build; exit"
cp -f correspondPixels.mex* ../benchmarks/
